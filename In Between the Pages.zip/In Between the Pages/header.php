<head>
    
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" >
    <link rel="shortcut icon"
 href="page_icon.png">
    <title>In Between the pages</title>
    
    <!-- Bootsrap odhgies kai links apo to https://www.w3schools.com/-->
      <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
    <!--Gramatoseires apo thn Google sto https://fonts.google.com/ -->
    <link rel="stylesheet" href="bookpage.css">
    <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">    
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">

</head>